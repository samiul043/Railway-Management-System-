CREATE DATABASE railway_reservation;

USE railway_reservation;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE trains (
    id INT AUTO_INCREMENT PRIMARY KEY,
    train_name VARCHAR(100) NOT NULL,
    source VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    total_seats INT NOT NULL,
    available_seats INT NOT NULL
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    train_id INT NOT NULL,
    booking_date DATE NOT NULL,
    status ENUM('booked', 'cancelled') DEFAULT 'booked',
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (train_id) REFERENCES trains(id)
);

CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    train_id INT NOT NULL,
    review TEXT NOT NULL,
    rating INT NOT NULL,
    review_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (train_id) REFERENCES trains(id)
);

INSERT INTO trains (train_name, source, destination, departure_time, arrival_time, total_seats, available_seats) VALUES
('Express 101', 'Dhaka', 'Chittagong', '08:00:00', '12:30:00', 500, 450),
('Superfast 202', 'Chittagong', 'Coxs Bazar', '14:00:00', '16:30:00', 300, 250),
('Passenger 303', 'Rajshahi', 'Dhaka', '06:00:00', '11:00:00', 800, 750),
('Express 404', 'Barishal', 'Coxs Bazar', '09:30:00', '18:00:00', 400, 350),
('Superfast 505', 'Dhaka', 'Pangchagar', '20:00:00', '06:00:00', 250, 200),
('Passenger 606', 'Cumilla', 'Dhaka', '07:00:00', '10:00:00', 600, 550),
('Express 707', 'Dhaka', 'Sylhet', '16:00:00', '22:00:00', 450, 400),
('Superfast 808', 'Sylhet', 'Chittagong', '10:00:00', '15:00:00', 350, 300),
('Passenger 909', 'Dhaka', 'Chittagong', '12:00:00', '18:00:00', 700, 650),
('Express 1010', 'Chittagong', 'Khulna', '18:30:00', '02:30:00', 500, 450);


INSERT INTO users (username, email, password) VALUES
('sadia_ahmed', 'sadia.ahmed@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('farhan_hossain', 'farhan.hossain@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('priya_das', 'priya.das@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('ariful_islam', 'ariful.islam@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('nusrat_jahan', 'nusrat.jahan@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('sohel_rana', 'sohel.rana@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('tania_sultana', 'tania.sultana@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('imran_hasan', 'imran.hasan@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('farhana_akter', 'farhana.akter@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('mahmud_rahman', 'mahmud.rahman@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('anika_islam', 'anika.islam@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('sanjida_haque', 'sanjida.haque@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('tahmid_hossain', 'tahmid.hossain@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('sabrina_alam', 'sabrina.alam@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('rasel_ahmed', 'rasel.ahmed@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('faria_sultana', 'faria.sultana@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('asif_hasan', 'asif.hasan@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('nadia_akter', 'nadia.akter@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('saiful_islam', 'saiful.islam@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm'),
('roksana_begum', 'roksana.begum@example.com', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm');


INSERT INTO bookings (user_id, train_id, booking_date, status)
VALUES
(1, 1, '2024-06-01', 'booked'),
(4, 3, '2024-06-02', 'booked'),
(7, 5, '2024-06-03', 'booked'),
(10, 7, '2024-06-04', 'booked'),
(13, 9, '2024-06-05', 'booked'),
(16, 2, '2024-06-06', 'cancelled'),
(19, 4, '2024-06-07', 'booked'),
(2, 6, '2024-06-08', 'booked'),
(5, 8, '2024-06-09', 'cancelled'),
(8, 10, '2024-06-10', 'booked');
