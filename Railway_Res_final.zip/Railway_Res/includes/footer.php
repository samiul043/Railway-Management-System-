<footer>
        <p>&copy; 2024 Railway Reservation System</p>
    </footer>
</body>
</html>
